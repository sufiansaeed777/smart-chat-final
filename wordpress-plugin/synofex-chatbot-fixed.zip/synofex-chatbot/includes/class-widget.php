<?php
/**
 * Synofex Chat Widget
 * Renders the chat widget on the frontend
 */

if (!defined('ABSPATH')) {
    exit;
}

class Synofex_Widget {

    /**
     * Widget configuration
     */
    private $config;

    /**
     * Constructor
     */
    public function __construct() {
        $this->config = get_option('synofex_bot_config', []);
    }

    /**
     * Render the widget
     */
    public function render($atts = []) {
        // Get widget settings
        $position = get_option('synofex_widget_position', 'bottom-right');
        $theme = get_option('synofex_widget_theme', 'light');
        $bot_id = $this->config['bot_id'] ?? 'general-assistant';
        $welcome_message = $this->config['welcome_message'] ?? __('Hello! How can I help you today?', 'synofex-chatbot');
        $placeholder = $this->config['placeholder'] ?? __('Type your message...', 'synofex-chatbot');

        // Override with shortcode attributes if provided
        if (!empty($atts)) {
            $position = $atts['position'] ?? $position;
            $theme = $atts['theme'] ?? $theme;
        }

        ?>
        <div id="synofex-chatbot-container"
             class="synofex-widget-container synofex-position-<?php echo esc_attr($position); ?> synofex-theme-<?php echo esc_attr($theme); ?>"
             data-bot-id="<?php echo esc_attr($bot_id); ?>">

            <!-- Chat Toggle Button -->
            <button id="synofex-chat-toggle" class="synofex-chat-toggle" aria-label="<?php esc_attr_e('Open chat', 'synofex-chatbot'); ?>">
                <svg class="synofex-chat-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 13.8214 2.48697 15.5291 3.33782 17.0002L2 22L7 20.662C8.46997 21.513 10.1786 22 12 22Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <svg class="synofex-close-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: none;">
                    <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <span class="synofex-unread-badge" style="display: none;">0</span>
            </button>

            <!-- Chat Window -->
            <div id="synofex-chat-window" class="synofex-chat-window" style="display: none;">
                <!-- Header -->
                <div class="synofex-chat-header">
                    <div class="synofex-bot-info">
                        <?php if (!empty($this->config['avatar'])): ?>
                            <img src="<?php echo esc_url($this->config['avatar']); ?>" alt="Bot Avatar" class="synofex-bot-avatar">
                        <?php else: ?>
                            <div class="synofex-bot-avatar-placeholder">
                                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/>
                                    <path d="M12 14C14.2091 14 16 12.2091 16 10C16 7.79086 14.2091 6 12 6C9.79086 6 8 7.79086 8 10C8 12.2091 9.79086 14 12 14Z" stroke="currentColor" stroke-width="2"/>
                                    <path d="M12 14C8.686 14 6 16.686 6 20H18C18 16.686 15.314 14 12 14Z" stroke="currentColor" stroke-width="2"/>
                                </svg>
                            </div>
                        <?php endif; ?>
                        <div class="synofex-bot-details">
                            <h3 class="synofex-bot-name"><?php echo esc_html($this->config['name'] ?? 'AI Assistant'); ?></h3>
                            <span class="synofex-bot-status">
                                <span class="synofex-status-dot"></span>
                                <?php esc_html_e('Online', 'synofex-chatbot'); ?>
                            </span>
                        </div>
                    </div>
                    <div class="synofex-chat-actions">
                        <button class="synofex-action-btn synofex-menu-btn" aria-label="<?php esc_attr_e('Menu', 'synofex-chatbot'); ?>">
                            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="12" cy="5" r="1" fill="currentColor"/>
                                <circle cx="12" cy="12" r="1" fill="currentColor"/>
                                <circle cx="12" cy="19" r="1" fill="currentColor"/>
                            </svg>
                        </button>
                        <button class="synofex-action-btn synofex-minimize-btn" aria-label="<?php esc_attr_e('Minimize', 'synofex-chatbot'); ?>">
                            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19 13H5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- Menu Dropdown -->
                <div class="synofex-chat-menu" style="display: none;">
                    <button class="synofex-menu-item" data-action="clear-chat">
                        <?php esc_html_e('Clear Chat', 'synofex-chatbot'); ?>
                    </button>
                    <button class="synofex-menu-item" data-action="export-chat">
                        <?php esc_html_e('Export Chat', 'synofex-chatbot'); ?>
                    </button>
                    <button class="synofex-menu-item" data-action="report-issue">
                        <?php esc_html_e('Report Issue', 'synofex-chatbot'); ?>
                    </button>
                    <button class="synofex-menu-item synofex-human-handoff" data-action="human-handoff">
                        <?php esc_html_e('Talk to Human', 'synofex-chatbot'); ?>
                    </button>
                    <button class="synofex-menu-item" data-action="end-chat">
                        <?php esc_html_e('End Chat', 'synofex-chatbot'); ?>
                    </button>
                </div>

                <!-- Messages Area -->
                <div class="synofex-chat-messages" id="synofex-chat-messages">
                    <!-- Welcome Message -->
                    <div class="synofex-message synofex-bot-message synofex-welcome-message">
                        <div class="synofex-message-avatar">
                            <?php if (!empty($this->config['avatar'])): ?>
                                <img src="<?php echo esc_url($this->config['avatar']); ?>" alt="Bot">
                            <?php else: ?>
                                <div class="synofex-avatar-placeholder">B</div>
                            <?php endif; ?>
                        </div>
                        <div class="synofex-message-content">
                            <div class="synofex-message-bubble">
                                <?php echo wp_kses_post($welcome_message); ?>
                            </div>
                            <div class="synofex-message-time">
                                <?php echo esc_html(current_time('g:i A')); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Typing Indicator -->
                <div class="synofex-typing-indicator" style="display: none;">
                    <div class="synofex-message synofex-bot-message">
                        <div class="synofex-message-avatar">
                            <?php if (!empty($this->config['avatar'])): ?>
                                <img src="<?php echo esc_url($this->config['avatar']); ?>" alt="Bot">
                            <?php else: ?>
                                <div class="synofex-avatar-placeholder">B</div>
                            <?php endif; ?>
                        </div>
                        <div class="synofex-message-content">
                            <div class="synofex-typing-dots">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- User Info Form (shown on first message if configured) -->
                <div class="synofex-user-form" id="synofex-user-form" style="display: none;">
                    <div class="synofex-form-content">
                        <h4><?php esc_html_e('Before we start', 'synofex-chatbot'); ?></h4>
                        <p><?php esc_html_e('Please provide your information:', 'synofex-chatbot'); ?></p>
                        <form id="synofex-info-form">
                            <input type="text" name="name" placeholder="<?php esc_attr_e('Your Name', 'synofex-chatbot'); ?>" required>
                            <input type="email" name="email" placeholder="<?php esc_attr_e('Your Email', 'synofex-chatbot'); ?>" required>
                            <input type="tel" name="phone" placeholder="<?php esc_attr_e('Your Phone (optional)', 'synofex-chatbot'); ?>">
                            <button type="submit" class="synofex-submit-btn">
                                <?php esc_html_e('Start Chat', 'synofex-chatbot'); ?>
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Input Area -->
                <div class="synofex-chat-input">
                    <form id="synofex-message-form" class="synofex-message-form">
                        <div class="synofex-input-group">
                            <textarea
                                id="synofex-message-input"
                                class="synofex-message-input"
                                placeholder="<?php echo esc_attr($placeholder); ?>"
                                rows="1"
                                maxlength="1000"></textarea>
                            <div class="synofex-input-actions">
                                <button type="button" class="synofex-attach-btn" aria-label="<?php esc_attr_e('Attach file', 'synofex-chatbot'); ?>" style="display: none;">
                                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M21 11L21 10C21 5.02944 16.9706 1 12 1C7.02944 1 3 5.02944 3 10L3 13C3 17.9706 7.02944 22 12 22H13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        <path d="M8 10V13C8 15.2091 9.79086 17 12 17C14.2091 17 16 15.2091 16 13V9.5C16 8.11929 14.8807 7 13.5 7C12.1193 7 11 8.11929 11 9.5V13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                    </svg>
                                </button>
                                <button type="submit" class="synofex-send-btn" aria-label="<?php esc_attr_e('Send message', 'synofex-chatbot'); ?>">
                                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M22 2L11 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M22 2L15 22L11 13L2 9L22 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        <div class="synofex-char-count">
                            <span id="synofex-char-current">0</span> / <span>1000</span>
                        </div>
                    </form>
                </div>

                <!-- Powered By -->
                <?php if ($this->should_show_branding()): ?>
                <div class="synofex-powered-by">
                    <a href="https://synofex.com" target="_blank" rel="noopener">
                        <?php esc_html_e('Powered by Synofex', 'synofex-chatbot'); ?>
                    </a>
                </div>
                <?php endif; ?>
            </div>

            <!-- Notification Toast -->
            <div class="synofex-notification" id="synofex-notification" style="display: none;">
                <div class="synofex-notification-content">
                    <span class="synofex-notification-message"></span>
                    <button class="synofex-notification-close">&times;</button>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Check if branding should be shown
     */
    private function should_show_branding() {
        $plan = $this->config['plan'] ?? 'free';
        return in_array($plan, ['free', 'starter']);
    }
}
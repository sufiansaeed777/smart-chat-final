<?php
/**
 * Synofex Settings Manager
 * Handles WordPress settings registration and sanitization
 */

if (!defined('ABSPATH')) {
    exit;
}

class Synofex_Settings {

    /**
     * Initialize settings
     */
    public static function init() {
        add_action('admin_init', [__CLASS__, 'register_settings']);
    }

    /**
     * Register plugin settings
     */
    public static function register_settings() {
        // Register settings group
        register_setting('synofex_settings_group', 'synofex_auth_token', [
            'sanitize_callback' => [__CLASS__, 'sanitize_auth_token']
        ]);

        register_setting('synofex_settings_group', 'synofex_api_url', [
            'sanitize_callback' => 'sanitize_url'
        ]);

        register_setting('synofex_settings_group', 'synofex_widget_enabled', [
            'sanitize_callback' => [__CLASS__, 'sanitize_checkbox']
        ]);

        register_setting('synofex_settings_group', 'synofex_widget_position', [
            'sanitize_callback' => [__CLASS__, 'sanitize_widget_position']
        ]);

        register_setting('synofex_settings_group', 'synofex_widget_theme', [
            'sanitize_callback' => [__CLASS__, 'sanitize_widget_theme']
        ]);

        register_setting('synofex_settings_group', 'synofex_show_on_pages', [
            'sanitize_callback' => [__CLASS__, 'sanitize_show_on_pages']
        ]);

        register_setting('synofex_settings_group', 'synofex_selected_pages', [
            'sanitize_callback' => [__CLASS__, 'sanitize_selected_pages']
        ]);

        register_setting('synofex_settings_group', 'synofex_cache_enabled', [
            'sanitize_callback' => [__CLASS__, 'sanitize_checkbox']
        ]);

        register_setting('synofex_settings_group', 'synofex_cache_duration', [
            'sanitize_callback' => [__CLASS__, 'sanitize_cache_duration']
        ]);
    }

    /**
     * Sanitize auth token
     */
    public static function sanitize_auth_token($value) {
        $token = sanitize_text_field($value);

        // If token changed, invalidate current validation
        $current_token = get_option('synofex_auth_token', '');
        if ($token !== $current_token) {
            delete_option('synofex_token_valid');
            delete_option('synofex_bot_config');
        }

        return $token;
    }

    /**
     * Sanitize checkbox values
     */
    public static function sanitize_checkbox($value) {
        return isset($value) && $value ? 1 : 0;
    }

    /**
     * Sanitize widget position
     */
    public static function sanitize_widget_position($value) {
        $allowed_positions = ['bottom-right', 'bottom-left', 'top-right', 'top-left'];
        return in_array($value, $allowed_positions) ? $value : 'bottom-right';
    }

    /**
     * Sanitize widget theme
     */
    public static function sanitize_widget_theme($value) {
        $allowed_themes = ['light', 'dark', 'auto'];
        return in_array($value, $allowed_themes) ? $value : 'light';
    }

    /**
     * Sanitize show on pages option
     */
    public static function sanitize_show_on_pages($value) {
        $allowed_options = ['all', 'specific', 'except'];
        return in_array($value, $allowed_options) ? $value : 'all';
    }

    /**
     * Sanitize selected pages
     */
    public static function sanitize_selected_pages($value) {
        if (!is_array($value)) {
            return [];
        }

        return array_map('intval', $value);
    }

    /**
     * Sanitize cache duration
     */
    public static function sanitize_cache_duration($value) {
        $duration = intval($value);
        return max(60, min(86400, $duration)); // Between 1 minute and 24 hours
    }

    /**
     * Get default settings
     */
    public static function get_defaults() {
        return [
            'synofex_auth_token' => '',
            'synofex_api_url' => 'https://api.synofex.com',
            'synofex_widget_enabled' => true,
            'synofex_widget_position' => 'bottom-right',
            'synofex_widget_theme' => 'light',
            'synofex_show_on_pages' => 'all',
            'synofex_selected_pages' => [],
            'synofex_cache_enabled' => true,
            'synofex_cache_duration' => 3600,
            'synofex_token_valid' => false,
            'synofex_bot_config' => []
        ];
    }

    /**
     * Reset all settings to defaults
     */
    public static function reset_to_defaults() {
        $defaults = self::get_defaults();

        foreach ($defaults as $option => $value) {
            update_option($option, $value);
        }

        // Clear cache
        $cache = new Synofex_Cache();
        $cache->clear_all();
    }

    /**
     * Export settings
     */
    public static function export_settings() {
        $settings = [];
        $defaults = self::get_defaults();

        foreach (array_keys($defaults) as $option) {
            $settings[$option] = get_option($option, $defaults[$option]);
        }

        // Remove sensitive data
        unset($settings['synofex_auth_token']);

        return $settings;
    }

    /**
     * Import settings
     */
    public static function import_settings($settings) {
        if (!is_array($settings)) {
            return false;
        }

        $defaults = self::get_defaults();
        $imported = 0;

        foreach ($settings as $option => $value) {
            if (array_key_exists($option, $defaults) && $option !== 'synofex_auth_token') {
                update_option($option, $value);
                $imported++;
            }
        }

        return $imported;
    }

    /**
     * Validate settings
     */
    public static function validate_settings() {
        $errors = [];

        // Check auth token
        $token = get_option('synofex_auth_token', '');
        if (empty($token)) {
            $errors[] = __('Auth token is required.', 'synofex-chatbot');
        }

        // Check API URL
        $api_url = get_option('synofex_api_url', '');
        if (empty($api_url) || !filter_var($api_url, FILTER_VALIDATE_URL)) {
            $errors[] = __('Valid API URL is required.', 'synofex-chatbot');
        }

        return $errors;
    }
}

// Initialize settings
Synofex_Settings::init();
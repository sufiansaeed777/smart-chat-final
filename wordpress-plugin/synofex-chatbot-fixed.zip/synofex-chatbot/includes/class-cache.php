<?php
/**
 * Synofex Cache Handler
 * Manages caching for API responses and configurations
 */

if (!defined('ABSPATH')) {
    exit;
}

class Synofex_Cache {

    /**
     * Cache prefix
     */
    private $prefix = 'synofex_cache_';

    /**
     * Default expiration time
     */
    private $default_expiration = 3600; // 1 hour

    /**
     * Get cached data
     */
    public function get($key) {
        if (!$this->is_enabled()) {
            return false;
        }

        return get_transient($this->prefix . $key);
    }

    /**
     * Set cached data
     */
    public function set($key, $value, $expiration = null) {
        if (!$this->is_enabled()) {
            return false;
        }

        if (null === $expiration) {
            $expiration = $this->default_expiration;
        }

        return set_transient($this->prefix . $key, $value, $expiration);
    }

    /**
     * Delete cached data
     */
    public function delete($key) {
        return delete_transient($this->prefix . $key);
    }

    /**
     * Clear all cache
     */
    public function clear_all() {
        global $wpdb;

        $sql = "DELETE FROM {$wpdb->options}
                WHERE option_name LIKE '%_transient_{$this->prefix}%'
                OR option_name LIKE '%_transient_timeout_{$this->prefix}%'";

        return $wpdb->query($sql);
    }

    /**
     * Check if caching is enabled
     */
    private function is_enabled() {
        return get_option('synofex_cache_enabled', true);
    }

    /**
     * Get cache statistics
     */
    public function get_stats() {
        global $wpdb;

        $count = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->options}
             WHERE option_name LIKE '%_transient_{$this->prefix}%'"
        );

        $size = $wpdb->get_var(
            "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options}
             WHERE option_name LIKE '%_transient_{$this->prefix}%'"
        );

        return [
            'count' => $count,
            'size' => size_format($size ?: 0),
        ];
    }
}
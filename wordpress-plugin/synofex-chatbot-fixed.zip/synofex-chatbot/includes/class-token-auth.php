<?php
/**
 * Synofex Token Authentication
 * Handles token-based authentication and domain binding
 */

if (!defined('ABSPATH')) {
    exit;
}

class Synofex_Token_Auth {

    /**
     * Validate token with domain
     */
    public static function validate_token($token, $domain) {
        if (empty($token) || empty($domain)) {
            return false;
        }

        $api_client = new Synofex_API_Client($token);
        return $api_client->validate_token($domain);
    }

    /**
     * Check if current token is valid
     */
    public static function is_token_valid() {
        return get_option('synofex_token_valid', false);
    }

    /**
     * Get current auth token
     */
    public static function get_token() {
        return get_option('synofex_auth_token', '');
    }

    /**
     * Set auth token
     */
    public static function set_token($token) {
        update_option('synofex_auth_token', sanitize_text_field($token));
    }

    /**
     * Clear token and validation status
     */
    public static function clear_token() {
        delete_option('synofex_auth_token');
        delete_option('synofex_token_valid');
        delete_option('synofex_bot_config');
    }

    /**
     * Generate secure headers for API requests
     */
    public static function get_auth_headers($token = null) {
        if (!$token) {
            $token = self::get_token();
        }

        return [
            'Authorization' => 'Bearer ' . $token,
            'Content-Type' => 'application/json',
            'X-Source' => 'wordpress',
            'X-Domain' => get_site_url(),
            'X-Plugin-Version' => SYNOFEX_CHATBOT_VERSION,
            'User-Agent' => 'SynofexChatbot/' . SYNOFEX_CHATBOT_VERSION . ' WordPress/' . get_bloginfo('version')
        ];
    }

    /**
     * Verify webhook signature
     */
    public static function verify_webhook_signature($payload, $signature, $secret = null) {
        if (!$secret) {
            $secret = self::get_token();
        }

        $expected_signature = hash_hmac('sha256', $payload, $secret);
        return hash_equals($expected_signature, $signature);
    }

    /**
     * Check if domain is authorized
     */
    public static function is_domain_authorized($domain = null) {
        if (!$domain) {
            $domain = get_site_url();
        }

        $bot_config = get_option('synofex_bot_config', []);
        return isset($bot_config['domain_allowed']) && $bot_config['domain_allowed'];
    }

    /**
     * Refresh token validation
     */
    public static function refresh_validation() {
        $token = self::get_token();
        if (!$token) {
            return false;
        }

        $domain = get_site_url();
        $validation = self::validate_token($token, $domain);

        if ($validation && isset($validation['valid']) && $validation['valid']) {
            update_option('synofex_token_valid', true);
            update_option('synofex_bot_config', $validation['config']);
            return true;
        } else {
            update_option('synofex_token_valid', false);
            return false;
        }
    }
}
<?php
/**
 * Synofex Admin Interface
 * Handles all admin functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class Synofex_Admin {

    /**
     * Render settings page
     */
    public function render_settings_page() {
        // Get current settings
        $auth_token = get_option('synofex_auth_token', '');
        $token_valid = get_option('synofex_token_valid', false);
        $bot_config = get_option('synofex_bot_config', []);
        $widget_enabled = get_option('synofex_widget_enabled', true);
        $widget_position = get_option('synofex_widget_position', 'bottom-right');
        $widget_theme = get_option('synofex_widget_theme', 'light');
        $show_on_pages = get_option('synofex_show_on_pages', 'all');
        $cache_enabled = get_option('synofex_cache_enabled', true);
        $api_url = get_option('synofex_api_url', 'https://api.synofex.com');

        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Synofex Chatbot Settings', 'synofex-chatbot'); ?></h1>

            <?php if (isset($_GET['settings-updated'])): ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php esc_html_e('Settings saved successfully!', 'synofex-chatbot'); ?></p>
                </div>
            <?php endif; ?>

            <div class="synofex-admin-container">
                <!-- Status Card -->
                <div class="card synofex-status-card">
                    <h2><?php esc_html_e('Connection Status', 'synofex-chatbot'); ?></h2>
                    <div class="synofex-status-info">
                        <div class="synofex-status-item">
                            <span class="synofex-status-label"><?php esc_html_e('Status:', 'synofex-chatbot'); ?></span>
                            <?php if ($token_valid): ?>
                                <span class="synofex-status-value synofex-status-connected">
                                    <span class="dashicons dashicons-yes-alt"></span>
                                    <?php esc_html_e('Connected', 'synofex-chatbot'); ?>
                                </span>
                            <?php else: ?>
                                <span class="synofex-status-value synofex-status-disconnected">
                                    <span class="dashicons dashicons-dismiss"></span>
                                    <?php esc_html_e('Not Connected', 'synofex-chatbot'); ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <?php if ($token_valid && !empty($bot_config)): ?>
                            <div class="synofex-status-item">
                                <span class="synofex-status-label"><?php esc_html_e('Bot:', 'synofex-chatbot'); ?></span>
                                <span class="synofex-status-value"><?php echo esc_html($bot_config['name'] ?? 'Unknown'); ?></span>
                            </div>
                            <div class="synofex-status-item">
                                <span class="synofex-status-label"><?php esc_html_e('Plan:', 'synofex-chatbot'); ?></span>
                                <span class="synofex-status-value"><?php echo esc_html(ucfirst($bot_config['plan'] ?? 'free')); ?></span>
                            </div>
                            <div class="synofex-status-item">
                                <span class="synofex-status-label"><?php esc_html_e('Messages:', 'synofex-chatbot'); ?></span>
                                <span class="synofex-status-value">
                                    <?php echo esc_html($bot_config['usage']['messages'] ?? 0); ?> /
                                    <?php echo esc_html($bot_config['limits']['messages'] ?? '∞'); ?>
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Settings Form -->
                <form method="post" action="options.php" class="synofex-settings-form">
                    <?php settings_fields('synofex_settings_group'); ?>

                    <!-- Authentication Settings -->
                    <div class="card">
                        <h2><?php esc_html_e('Authentication', 'synofex-chatbot'); ?></h2>
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="synofex_auth_token"><?php esc_html_e('Auth Token', 'synofex-chatbot'); ?></label>
                                </th>
                                <td>
                                    <input type="text"
                                           id="synofex_auth_token"
                                           name="synofex_auth_token"
                                           value="<?php echo esc_attr($auth_token); ?>"
                                           class="regular-text"
                                           placeholder="Enter your Synofex auth token">
                                    <button type="button" id="synofex-validate-token" class="button button-secondary">
                                        <?php esc_html_e('Validate Token', 'synofex-chatbot'); ?>
                                    </button>
                                    <p class="description">
                                        <?php esc_html_e('Get your auth token from the Synofex dashboard.', 'synofex-chatbot'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="synofex_api_url"><?php esc_html_e('API URL', 'synofex-chatbot'); ?></label>
                                </th>
                                <td>
                                    <input type="url"
                                           id="synofex_api_url"
                                           name="synofex_api_url"
                                           value="<?php echo esc_attr($api_url); ?>"
                                           class="regular-text">
                                    <p class="description">
                                        <?php esc_html_e('Custom API endpoint (leave default for production).', 'synofex-chatbot'); ?>
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- Widget Settings -->
                    <div class="card">
                        <h2><?php esc_html_e('Widget Settings', 'synofex-chatbot'); ?></h2>
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="synofex_widget_enabled"><?php esc_html_e('Enable Widget', 'synofex-chatbot'); ?></label>
                                </th>
                                <td>
                                    <label class="synofex-toggle">
                                        <input type="checkbox"
                                               id="synofex_widget_enabled"
                                               name="synofex_widget_enabled"
                                               value="1"
                                               <?php checked($widget_enabled, true); ?>>
                                        <span class="synofex-toggle-slider"></span>
                                    </label>
                                    <p class="description">
                                        <?php esc_html_e('Enable or disable the chat widget on your site.', 'synofex-chatbot'); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="synofex_widget_position"><?php esc_html_e('Widget Position', 'synofex-chatbot'); ?></label>
                                </th>
                                <td>
                                    <select id="synofex_widget_position" name="synofex_widget_position">
                                        <option value="bottom-right" <?php selected($widget_position, 'bottom-right'); ?>>
                                            <?php esc_html_e('Bottom Right', 'synofex-chatbot'); ?>
                                        </option>
                                        <option value="bottom-left" <?php selected($widget_position, 'bottom-left'); ?>>
                                            <?php esc_html_e('Bottom Left', 'synofex-chatbot'); ?>
                                        </option>
                                        <option value="top-right" <?php selected($widget_position, 'top-right'); ?>>
                                            <?php esc_html_e('Top Right', 'synofex-chatbot'); ?>
                                        </option>
                                        <option value="top-left" <?php selected($widget_position, 'top-left'); ?>>
                                            <?php esc_html_e('Top Left', 'synofex-chatbot'); ?>
                                        </option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="synofex_widget_theme"><?php esc_html_e('Widget Theme', 'synofex-chatbot'); ?></label>
                                </th>
                                <td>
                                    <select id="synofex_widget_theme" name="synofex_widget_theme">
                                        <option value="light" <?php selected($widget_theme, 'light'); ?>>
                                            <?php esc_html_e('Light', 'synofex-chatbot'); ?>
                                        </option>
                                        <option value="dark" <?php selected($widget_theme, 'dark'); ?>>
                                            <?php esc_html_e('Dark', 'synofex-chatbot'); ?>
                                        </option>
                                        <option value="auto" <?php selected($widget_theme, 'auto'); ?>>
                                            <?php esc_html_e('Auto (System)', 'synofex-chatbot'); ?>
                                        </option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="synofex_show_on_pages"><?php esc_html_e('Show On', 'synofex-chatbot'); ?></label>
                                </th>
                                <td>
                                    <select id="synofex_show_on_pages" name="synofex_show_on_pages">
                                        <option value="all" <?php selected($show_on_pages, 'all'); ?>>
                                            <?php esc_html_e('All Pages', 'synofex-chatbot'); ?>
                                        </option>
                                        <option value="specific" <?php selected($show_on_pages, 'specific'); ?>>
                                            <?php esc_html_e('Specific Pages', 'synofex-chatbot'); ?>
                                        </option>
                                        <option value="except" <?php selected($show_on_pages, 'except'); ?>>
                                            <?php esc_html_e('All Except', 'synofex-chatbot'); ?>
                                        </option>
                                    </select>
                                    <div id="synofex-page-selector" style="display: <?php echo ($show_on_pages !== 'all') ? 'block' : 'none'; ?>; margin-top: 10px;">
                                        <?php
                                        $pages = get_pages();
                                        $selected_pages = get_option('synofex_selected_pages', []);
                                        foreach ($pages as $page) {
                                            ?>
                                            <label style="display: block; margin: 5px 0;">
                                                <input type="checkbox"
                                                       name="synofex_selected_pages[]"
                                                       value="<?php echo esc_attr($page->ID); ?>"
                                                       <?php checked(in_array($page->ID, $selected_pages)); ?>>
                                                <?php echo esc_html($page->post_title); ?>
                                            </label>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- Performance Settings -->
                    <div class="card">
                        <h2><?php esc_html_e('Performance', 'synofex-chatbot'); ?></h2>
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="synofex_cache_enabled"><?php esc_html_e('Enable Cache', 'synofex-chatbot'); ?></label>
                                </th>
                                <td>
                                    <label class="synofex-toggle">
                                        <input type="checkbox"
                                               id="synofex_cache_enabled"
                                               name="synofex_cache_enabled"
                                               value="1"
                                               <?php checked($cache_enabled, true); ?>>
                                        <span class="synofex-toggle-slider"></span>
                                    </label>
                                    <p class="description">
                                        <?php esc_html_e('Cache API responses for better performance.', 'synofex-chatbot'); ?>
                                    </p>
                                </td>
                            </tr>
                            <?php if ($cache_enabled): ?>
                            <tr>
                                <th scope="row">
                                    <?php esc_html_e('Cache Stats', 'synofex-chatbot'); ?>
                                </th>
                                <td>
                                    <?php
                                    $cache = new Synofex_Cache();
                                    $stats = $cache->get_stats();
                                    ?>
                                    <p>
                                        <?php echo esc_html(sprintf(
                                            __('Items: %d | Size: %s', 'synofex-chatbot'),
                                            $stats['count'],
                                            $stats['size']
                                        )); ?>
                                    </p>
                                    <button type="button" id="synofex-clear-cache" class="button button-secondary">
                                        <?php esc_html_e('Clear Cache', 'synofex-chatbot'); ?>
                                    </button>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    </div>

                    <?php submit_button(); ?>
                </form>

                <!-- Shortcode Info -->
                <div class="card">
                    <h2><?php esc_html_e('Shortcode', 'synofex-chatbot'); ?></h2>
                    <p><?php esc_html_e('Use this shortcode to display the chatbot on specific pages or posts:', 'synofex-chatbot'); ?></p>
                    <code>[synofex_chatbot position="bottom-right" theme="light"]</code>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render analytics page
     */
    public function render_analytics_page() {
        $api_client = new Synofex_API_Client(get_option('synofex_auth_token'));
        $analytics = $api_client->get_analytics(null, '7days');

        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Chatbot Analytics', 'synofex-chatbot'); ?></h1>

            <?php if (!get_option('synofex_token_valid', false)): ?>
                <div class="notice notice-warning">
                    <p><?php esc_html_e('Please configure your auth token first.', 'synofex-chatbot'); ?></p>
                </div>
                <p>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=synofex-chatbot')); ?>" class="button button-primary">
                        <?php esc_html_e('Go to Settings', 'synofex-chatbot'); ?>
                    </a>
                </p>
            <?php elseif (empty($analytics)): ?>
                <div class="notice notice-info">
                    <p><?php esc_html_e('No analytics data available yet.', 'synofex-chatbot'); ?></p>
                </div>
            <?php else: ?>
                <div class="synofex-analytics-grid">
                    <!-- Metrics Cards -->
                    <div class="synofex-metric-card">
                        <h3><?php esc_html_e('Total Conversations', 'synofex-chatbot'); ?></h3>
                        <div class="synofex-metric-value"><?php echo esc_html($analytics['total_conversations'] ?? 0); ?></div>
                    </div>

                    <div class="synofex-metric-card">
                        <h3><?php esc_html_e('Messages Sent', 'synofex-chatbot'); ?></h3>
                        <div class="synofex-metric-value"><?php echo esc_html($analytics['total_messages'] ?? 0); ?></div>
                    </div>

                    <div class="synofex-metric-card">
                        <h3><?php esc_html_e('Unique Users', 'synofex-chatbot'); ?></h3>
                        <div class="synofex-metric-value"><?php echo esc_html($analytics['unique_users'] ?? 0); ?></div>
                    </div>

                    <div class="synofex-metric-card">
                        <h3><?php esc_html_e('Avg Response Time', 'synofex-chatbot'); ?></h3>
                        <div class="synofex-metric-value"><?php echo esc_html($analytics['avg_response_time'] ?? '0'); ?>s</div>
                    </div>
                </div>

                <!-- Recent Conversations -->
                <div class="card" style="margin-top: 20px;">
                    <h2><?php esc_html_e('Recent Conversations', 'synofex-chatbot'); ?></h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('Time', 'synofex-chatbot'); ?></th>
                                <th><?php esc_html_e('User', 'synofex-chatbot'); ?></th>
                                <th><?php esc_html_e('Messages', 'synofex-chatbot'); ?></th>
                                <th><?php esc_html_e('Status', 'synofex-chatbot'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $logs = $api_client->get_logs(null, 20);
                            if ($logs && is_array($logs)):
                                foreach ($logs as $log):
                            ?>
                                <tr>
                                    <td><?php echo esc_html(human_time_diff(strtotime($log['created_at']))); ?> ago</td>
                                    <td><?php echo esc_html($log['user_id'] ?? 'Guest'); ?></td>
                                    <td><?php echo esc_html($log['message_count'] ?? 1); ?></td>
                                    <td>
                                        <span class="synofex-status-badge synofex-status-<?php echo esc_attr($log['status'] ?? 'active'); ?>">
                                            <?php echo esc_html(ucfirst($log['status'] ?? 'active')); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php
                                endforeach;
                            else:
                            ?>
                                <tr>
                                    <td colspan="4"><?php esc_html_e('No conversations yet.', 'synofex-chatbot'); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}
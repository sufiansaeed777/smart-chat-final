/**
 * Synofex Admin Panel JavaScript
 * Handles WordPress admin interface functionality
 */

(function($) {
    'use strict';

    class SynofexAdmin {
        constructor() {
            this.config = window.synofex_admin || {};
            this.init();
        }

        init() {
            this.bindEvents();
            this.initPageSelector();
            this.loadAnalytics();
        }

        bindEvents() {
            // Token validation
            $(document).on('click', '#synofex-validate-token', (e) => {
                e.preventDefault();
                this.validateToken();
            });

            // Clear cache
            $(document).on('click', '#synofex-clear-cache', (e) => {
                e.preventDefault();
                this.clearCache();
            });

            // Page selector toggle
            $(document).on('change', '#synofex_show_on_pages', (e) => {
                this.togglePageSelector($(e.target).val());
            });

            // Auto-save settings
            $(document).on('change', 'input, select', () => {
                this.showUnsavedChanges();
            });

            // Form submission
            $(document).on('submit', '.synofex-settings-form', (e) => {
                this.handleFormSubmission(e);
            });

            // Test connection
            $(document).on('click', '#synofex-test-connection', (e) => {
                e.preventDefault();
                this.testConnection();
            });
        }

        validateToken() {
            const $button = $('#synofex-validate-token');
            const $token = $('#synofex_auth_token');
            const token = $token.val().trim();

            if (!token) {
                this.showMessage('Please enter an auth token.', 'error');
                $token.focus();
                return;
            }

            $button.addClass('loading').prop('disabled', true);

            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'synofex_validate_token',
                    nonce: this.config.nonce,
                    token: token
                },
                timeout: 30000
            })
            .done((response) => {
                if (response.success) {
                    this.showMessage(
                        response.data.message || 'Token validated successfully!',
                        'success'
                    );
                    this.updateConnectionStatus(true, response.data.config);
                } else {
                    this.showMessage(
                        response.data || 'Token validation failed.',
                        'error'
                    );
                    this.updateConnectionStatus(false);
                }
            })
            .fail((jqXHR) => {
                let message = 'Connection failed. Please check your API URL and try again.';

                if (jqXHR.status === 401) {
                    message = 'Invalid token. Please check your auth token.';
                } else if (jqXHR.status === 403) {
                    message = 'Domain not authorized. Please check your domain settings.';
                } else if (jqXHR.status >= 500) {
                    message = 'Server error. Please try again later.';
                }

                this.showMessage(message, 'error');
                this.updateConnectionStatus(false);
            })
            .always(() => {
                $button.removeClass('loading').prop('disabled', false);
            });
        }

        clearCache() {
            if (!confirm('Are you sure you want to clear the cache?')) {
                return;
            }

            const $button = $('#synofex-clear-cache');
            $button.addClass('loading').prop('disabled', true);

            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'synofex_clear_cache',
                    nonce: this.config.nonce
                }
            })
            .done((response) => {
                if (response.success) {
                    this.showMessage('Cache cleared successfully.', 'success');
                    this.updateCacheStats();
                } else {
                    this.showMessage('Failed to clear cache.', 'error');
                }
            })
            .fail(() => {
                this.showMessage('Failed to clear cache.', 'error');
            })
            .always(() => {
                $button.removeClass('loading').prop('disabled', false);
            });
        }

        testConnection() {
            const $button = $('#synofex-test-connection');
            $button.addClass('loading').prop('disabled', true);

            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'synofex_test_connection',
                    nonce: this.config.nonce
                }
            })
            .done((response) => {
                if (response.success) {
                    this.showMessage('Connection test successful!', 'success');
                    $('#connection-status').html('✓ Connected');
                } else {
                    this.showMessage('Connection test failed.', 'error');
                    $('#connection-status').html('✗ Disconnected');
                }
            })
            .fail(() => {
                this.showMessage('Connection test failed.', 'error');
                $('#connection-status').html('✗ Disconnected');
            })
            .always(() => {
                $button.removeClass('loading').prop('disabled', false);
            });
        }

        initPageSelector() {
            const showOn = $('#synofex_show_on_pages').val();
            this.togglePageSelector(showOn);
        }

        togglePageSelector(value) {
            const $selector = $('#synofex-page-selector');

            if (value === 'specific' || value === 'except') {
                $selector.slideDown();
            } else {
                $selector.slideUp();
            }
        }

        updateConnectionStatus(connected, config = null) {
            const $status = $('.synofex-status-card');

            if (connected) {
                $status.removeClass('disconnected').addClass('connected');

                if (config) {
                    // Update status display with bot config
                    this.updateBotInfo(config);
                }
            } else {
                $status.removeClass('connected').addClass('disconnected');
            }
        }

        updateBotInfo(config) {
            // Update bot information display
            if (config.name) {
                $('.synofex-bot-name').text(config.name);
            }

            if (config.plan) {
                $('.synofex-plan-type').text(config.plan);
            }
        }

        updateCacheStats() {
            // Refresh cache statistics
            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'synofex_get_cache_stats',
                    nonce: this.config.nonce
                }
            })
            .done((response) => {
                if (response.success && response.data) {
                    $('.synofex-cache-stats').html(
                        `Items: ${response.data.count} | Size: ${response.data.size}`
                    );
                }
            });
        }

        loadAnalytics() {
            const $analyticsPage = $('.synofex-analytics-container');

            if (!$analyticsPage.length) {
                return;
            }

            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'synofex_get_analytics',
                    nonce: this.config.nonce,
                    period: '7days'
                }
            })
            .done((response) => {
                if (response.success && response.data) {
                    this.updateAnalyticsDisplay(response.data);
                }
            })
            .fail(() => {
                this.showMessage('Failed to load analytics data.', 'error');
            });
        }

        updateAnalyticsDisplay(data) {
            // Update metric cards
            $('#total-conversations').text(data.total_conversations || 0);
            $('#messages-today').text(data.messages_today || 0);
            $('#active-users').text(data.active_users || 0);
            $('#response-time').text((data.avg_response_time || 0) + 's');

            // Update recent conversations
            if (data.recent_conversations) {
                this.updateRecentConversations(data.recent_conversations);
            }
        }

        updateRecentConversations(conversations) {
            const $container = $('#recent-conversations');

            if (!conversations.length) {
                $container.html('<p>No recent conversations.</p>');
                return;
            }

            let html = '<table class="wp-list-table widefat fixed striped">';
            html += '<thead><tr><th>Time</th><th>User</th><th>Messages</th><th>Status</th></tr></thead>';
            html += '<tbody>';

            conversations.forEach(conv => {
                html += `
                    <tr>
                        <td>${this.formatTime(conv.created_at)}</td>
                        <td>${conv.user_name || 'Guest'}</td>
                        <td>${conv.message_count || 1}</td>
                        <td><span class="synofex-status-badge synofex-status-${conv.status || 'active'}">${conv.status || 'Active'}</span></td>
                    </tr>
                `;
            });

            html += '</tbody></table>';
            $container.html(html);
        }

        formatTime(timestamp) {
            const date = new Date(timestamp);
            const now = new Date();
            const diff = now - date;
            const minutes = Math.floor(diff / 60000);
            const hours = Math.floor(minutes / 60);
            const days = Math.floor(hours / 24);

            if (days > 0) {
                return `${days} day${days > 1 ? 's' : ''} ago`;
            } else if (hours > 0) {
                return `${hours} hour${hours > 1 ? 's' : ''} ago`;
            } else if (minutes > 0) {
                return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
            } else {
                return 'Just now';
            }
        }

        showMessage(message, type = 'info') {
            // Remove existing messages
            $('.synofex-message').remove();

            const $message = $(`
                <div class="synofex-message synofex-message-${type}">
                    ${message}
                </div>
            `);

            $('.synofex-admin-container').prepend($message);

            // Auto-hide after 5 seconds
            setTimeout(() => {
                $message.fadeOut(() => $message.remove());
            }, 5000);

            // Scroll to top to show message
            $('html, body').animate({
                scrollTop: $('.synofex-admin-container').offset().top - 50
            }, 300);
        }

        showUnsavedChanges() {
            if (!$('.synofex-unsaved-notice').length) {
                const $notice = $(`
                    <div class="synofex-message synofex-message-warning synofex-unsaved-notice">
                        You have unsaved changes. Don't forget to save your settings.
                    </div>
                `);
                $('.synofex-admin-container').prepend($notice);
            }
        }

        handleFormSubmission(e) {
            const $form = $(e.target);
            const $submitButton = $form.find('input[type="submit"]');

            $submitButton.prop('disabled', true).val('Saving...');

            // Remove unsaved changes notice
            $('.synofex-unsaved-notice').remove();

            // Re-enable button after form submission
            setTimeout(() => {
                $submitButton.prop('disabled', false).val('Save Changes');
            }, 2000);
        }

        // Utility methods
        debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
    }

    // Initialize when DOM is ready
    $(document).ready(function() {
        if ($('.synofex-admin-container').length) {
            window.synofexAdmin = new SynofexAdmin();
        }
    });

})(jQuery);
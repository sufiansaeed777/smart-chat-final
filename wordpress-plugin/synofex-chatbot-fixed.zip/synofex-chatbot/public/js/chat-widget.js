/**
 * Synofex Chat Widget JavaScript
 * Handles all frontend chat functionality
 */

(function($) {
    'use strict';

    class SynofexChatWidget {
        constructor() {
            this.isOpen = false;
            this.isTyping = false;
            this.sessionId = null;
            this.userInfo = null;
            this.messageHistory = [];
            this.config = window.synofex_config || {};

            this.init();
        }

        init() {
            this.bindEvents();
            this.setupAutoResize();
            this.loadUserInfo();
            this.setupHeartbeat();
        }

        bindEvents() {
            // Toggle button
            $(document).on('click', '#synofex-chat-toggle', (e) => {
                e.preventDefault();
                this.toggleChat();
            });

            // Message form
            $(document).on('submit', '#synofex-message-form', (e) => {
                e.preventDefault();
                this.sendMessage();
            });

            // User info form
            $(document).on('submit', '#synofex-info-form', (e) => {
                e.preventDefault();
                this.submitUserInfo();
            });

            // Menu actions
            $(document).on('click', '.synofex-menu-btn', () => {
                this.toggleMenu();
            });

            $(document).on('click', '.synofex-minimize-btn', () => {
                this.toggleChat();
            });

            $(document).on('click', '.synofex-menu-item', (e) => {
                const action = $(e.target).data('action');
                this.handleMenuAction(action);
            });

            // Input handlers
            $(document).on('input', '#synofex-message-input', (e) => {
                this.handleInputChange(e);
            });

            $(document).on('keydown', '#synofex-message-input', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });

            // Close menu when clicking outside
            $(document).on('click', (e) => {
                if (!$(e.target).closest('.synofex-chat-menu, .synofex-menu-btn').length) {
                    $('.synofex-chat-menu').hide();
                }
            });

            // Notification close
            $(document).on('click', '.synofex-notification-close', () => {
                this.hideNotification();
            });
        }

        toggleChat() {
            const $window = $('#synofex-chat-window');
            const $toggle = $('#synofex-chat-toggle');

            if (this.isOpen) {
                $window.removeClass('show');
                $toggle.removeClass('active');
                this.isOpen = false;
            } else {
                $window.addClass('show').show();
                $toggle.addClass('active');
                this.isOpen = true;
                this.clearUnreadBadge();
                this.scrollToBottom();

                // Show user form if required
                if (this.shouldShowUserForm()) {
                    $('#synofex-user-form').show();
                }
            }
        }

        shouldShowUserForm() {
            return !this.userInfo && this.config.bot_config &&
                   this.config.bot_config.collect_user_info &&
                   this.messageHistory.length === 0;
        }

        submitUserInfo() {
            const name = $('#synofex-info-form input[name="name"]').val();
            const email = $('#synofex-info-form input[name="email"]').val();
            const phone = $('#synofex-info-form input[name="phone"]').val();

            if (!name || !email) {
                this.showNotification('Please fill in required fields.', 'error');
                return;
            }

            this.userInfo = { name, email, phone };
            localStorage.setItem('synofex_user_info', JSON.stringify(this.userInfo));

            $('#synofex-user-form').hide();
            this.showNotification(`Welcome, ${name}!`, 'success');
        }

        loadUserInfo() {
            const stored = localStorage.getItem('synofex_user_info');
            if (stored) {
                try {
                    this.userInfo = JSON.parse(stored);
                } catch (e) {
                    localStorage.removeItem('synofex_user_info');
                }
            }
        }

        sendMessage() {
            const $input = $('#synofex-message-input');
            const message = $input.val().trim();

            if (!message || this.isTyping) {
                return;
            }

            // Add user message to chat
            this.addMessage(message, 'user');
            $input.val('');
            this.updateCharCount();
            this.adjustTextareaHeight($input[0]);

            // Show typing indicator
            this.showTyping();

            // Send to API
            this.sendToAPI(message);
        }

        addMessage(content, sender, options = {}) {
            const $messages = $('#synofex-chat-messages');
            const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

            let avatarHtml = '';
            if (sender === 'user') {
                const initial = this.userInfo?.name?.charAt(0).toUpperCase() || 'U';
                avatarHtml = `<div class="synofex-message-avatar">${initial}</div>`;
            } else {
                if (this.config.bot_config?.avatar) {
                    avatarHtml = `<div class="synofex-message-avatar"><img src="${this.config.bot_config.avatar}" alt="Bot"></div>`;
                } else {
                    avatarHtml = `<div class="synofex-message-avatar"><div class="synofex-avatar-placeholder">B</div></div>`;
                }
            }

            const messageHtml = `
                <div class="synofex-message synofex-${sender}-message">
                    ${avatarHtml}
                    <div class="synofex-message-content">
                        <div class="synofex-message-bubble">${this.formatMessage(content)}</div>
                        <div class="synofex-message-time">${timestamp}</div>
                    </div>
                </div>
            `;

            $messages.append(messageHtml);
            this.scrollToBottom();

            // Store in history
            this.messageHistory.push({
                content,
                sender,
                timestamp: new Date().toISOString(),
                ...options
            });
        }

        formatMessage(content) {
            // Basic HTML escaping and formatting
            return content
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;')
                .replace(/\n/g, '<br>');
        }

        showTyping() {
            this.isTyping = true;
            $('.synofex-typing-indicator').show();
            this.scrollToBottom();
        }

        hideTyping() {
            this.isTyping = false;
            $('.synofex-typing-indicator').hide();
        }

        sendToAPI(message) {
            const data = {
                bot_id: this.config.bot_config?.bot_id || 'default',
                message: message,
                session_id: this.sessionId,
                metadata: {
                    user_info: this.userInfo,
                    user_ip: this.getUserIP(),
                    user_agent: navigator.userAgent,
                    page_url: window.location.href,
                    timestamp: new Date().toISOString()
                }
            };

            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'synofex_send_message',
                    nonce: this.config.nonce,
                    ...data
                },
                timeout: 30000
            })
            .done((response) => {
                this.hideTyping();

                if (response.success && response.data.response) {
                    this.addMessage(response.data.response, 'bot');
                    this.sessionId = response.data.session_id;
                } else {
                    this.addMessage(
                        'Sorry, I\'m having trouble responding right now. Please try again.',
                        'bot'
                    );
                }
            })
            .fail(() => {
                this.hideTyping();
                this.addMessage(
                    'I\'m currently offline. Please try again later or contact support.',
                    'bot'
                );
            });
        }

        getUserIP() {
            // This would typically be set server-side
            return this.config.user_ip || '';
        }

        toggleMenu() {
            $('.synofex-chat-menu').toggle();
        }

        handleMenuAction(action) {
            $('.synofex-chat-menu').hide();

            switch (action) {
                case 'clear-chat':
                    this.clearChat();
                    break;
                case 'export-chat':
                    this.exportChat();
                    break;
                case 'report-issue':
                    this.reportIssue();
                    break;
                case 'human-handoff':
                    this.requestHumanHandoff();
                    break;
                case 'end-chat':
                    this.endChat();
                    break;
            }
        }

        clearChat() {
            if (confirm('Are you sure you want to clear the chat history?')) {
                $('#synofex-chat-messages').empty();
                this.messageHistory = [];
                this.sessionId = null;

                // Re-add welcome message
                this.addWelcomeMessage();
                this.showNotification('Chat cleared.', 'success');
            }
        }

        addWelcomeMessage() {
            const welcomeMsg = this.config.bot_config?.welcome_message ||
                              this.config.strings?.welcome ||
                              'Hello! How can I help you today?';

            setTimeout(() => {
                this.addMessage(welcomeMsg, 'bot');
            }, 500);
        }

        exportChat() {
            if (this.messageHistory.length === 0) {
                this.showNotification('No messages to export.', 'warning');
                return;
            }

            const chatData = {
                timestamp: new Date().toISOString(),
                session_id: this.sessionId,
                user_info: this.userInfo,
                messages: this.messageHistory
            };

            const blob = new Blob([JSON.stringify(chatData, null, 2)], {
                type: 'application/json'
            });

            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `synofex-chat-${new Date().toISOString().split('T')[0]}.json`;
            a.click();
            URL.revokeObjectURL(url);

            this.showNotification('Chat exported successfully.', 'success');
        }

        reportIssue() {
            const description = prompt('Please describe the issue:');
            if (!description) return;

            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'synofex_report_issue',
                    nonce: this.config.nonce,
                    bot_id: this.config.bot_config?.bot_id || 'default',
                    issue_type: 'user_report',
                    description: description,
                    session_id: this.sessionId
                }
            })
            .done(() => {
                this.showNotification('Issue reported. Thank you for your feedback!', 'success');
            })
            .fail(() => {
                this.showNotification('Failed to report issue. Please try again.', 'error');
            });
        }

        requestHumanHandoff() {
            if (confirm('Would you like to speak with a human agent?')) {
                this.addMessage('Connecting you to a human agent...', 'bot');

                $.ajax({
                    url: this.config.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'synofex_human_handoff',
                        nonce: this.config.nonce,
                        bot_id: this.config.bot_config?.bot_id || 'default',
                        session_id: this.sessionId,
                        reason: 'user_request'
                    }
                })
                .done(() => {
                    this.addMessage(
                        'A human agent will be with you shortly. Please wait...',
                        'bot'
                    );
                })
                .fail(() => {
                    this.addMessage(
                        'Sorry, human handoff is not available right now. Please try again later.',
                        'bot'
                    );
                });
            }
        }

        endChat() {
            if (confirm('Are you sure you want to end this chat session?')) {
                this.addMessage('Thank you for chatting with us! Have a great day!', 'bot');

                setTimeout(() => {
                    this.toggleChat();
                    this.clearChat();
                }, 2000);
            }
        }

        handleInputChange(e) {
            const $input = $(e.target);
            this.updateCharCount();
            this.adjustTextareaHeight($input[0]);

            // Update send button state
            const hasText = $input.val().trim().length > 0;
            $('.synofex-send-btn').prop('disabled', !hasText);
        }

        updateCharCount() {
            const $input = $('#synofex-message-input');
            const length = $input.val().length;
            const maxLength = $input.attr('maxlength') || 1000;

            $('#synofex-char-current').text(length);

            if (length > maxLength * 0.9) {
                $('.synofex-char-count').addClass('warning');
            } else {
                $('.synofex-char-count').removeClass('warning');
            }
        }

        adjustTextareaHeight(textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
        }

        setupAutoResize() {
            const $input = $('#synofex-message-input');
            if ($input.length) {
                this.adjustTextareaHeight($input[0]);
            }
        }

        scrollToBottom() {
            const $messages = $('#synofex-chat-messages');
            $messages.animate({
                scrollTop: $messages[0].scrollHeight
            }, 300);
        }

        showNotification(message, type = 'info') {
            const $notification = $('#synofex-notification');
            const $message = $('.synofex-notification-message');

            $message.text(message);
            $notification
                .removeClass('synofex-notification-success synofex-notification-error synofex-notification-warning')
                .addClass(`synofex-notification-${type}`)
                .addClass('show');

            setTimeout(() => {
                this.hideNotification();
            }, 5000);
        }

        hideNotification() {
            $('#synofex-notification').removeClass('show');
        }

        clearUnreadBadge() {
            $('.synofex-unread-badge').hide().text('0');
        }

        addUnreadMessage() {
            if (!this.isOpen) {
                const $badge = $('.synofex-unread-badge');
                const current = parseInt($badge.text()) || 0;
                $badge.text(current + 1).show();
            }
        }

        setupHeartbeat() {
            // Check connection status every 5 minutes
            setInterval(() => {
                this.checkConnection();
            }, 300000);
        }

        checkConnection() {
            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'synofex_heartbeat',
                    nonce: this.config.nonce
                },
                timeout: 10000
            })
            .done((response) => {
                if (response.success) {
                    $('.synofex-bot-status').html(`
                        <span class="synofex-status-dot"></span>
                        ${this.config.strings?.online || 'Online'}
                    `);
                }
            })
            .fail(() => {
                $('.synofex-bot-status').html(`
                    <span class="synofex-status-dot" style="background: #ff4757;"></span>
                    ${this.config.strings?.offline || 'Offline'}
                `);
            });
        }

        destroy() {
            $(document).off('.synofex');
            $('#synofex-chatbot-container').remove();
        }
    }

    // Initialize when DOM is ready
    $(document).ready(function() {
        // Check if widget container exists
        if ($('#synofex-chatbot-container').length) {
            window.synofexChatWidget = new SynofexChatWidget();
        }
    });

})(jQuery);